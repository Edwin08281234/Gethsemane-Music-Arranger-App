# Gethsemane Music Arranger — Android prototype
Upload all extracted files including `.github/workflows/android.yml` to the repository root. GitHub Actions > Build Android APK > latest successful run > Artifacts > Gethsemane-Music-Arranger. Extract artifact ZIP and install APK. Debug-signed, not a production release. No local Android SDK was available; build and device testing remain necessary.

Native app: local owner login, saved song list, editable lyrics/chords, section display, BPM and basic synthetic rhythm, Android text sharing. Local account is not centralized access control. Rhythm uses simple tones, not realistic drums or sample-accurate audio. No QR, live remote sync, audio import/transcription, notation or PDF export in native app yet. Optional-server contains earlier separate Python prototype, not integrated or tested here. Do not expose it publicly without security review.

## v0.5 additions and limitations
- Live browser session via same Wi-Fi/hotspot, QR and share link, read-only token, polling every 400 ms. Keep leader app open; end session to revoke. Bluetooth may share the URL but is not the live transport. Network isolation may prevent connection; URL interface selection may require adjustment on some phones. Local HTTP is not encrypted.
- Synthesized kick, snare, hi-hat and independent click; fixed 4/4 pattern, not studio samples or sample-accurate timing.
- PDF accompaniment sketch from manually entered chord symbols (space separated). Not a validated engraved score or audio transcription; no accidentals or minor voicing handling yet.
- Optional Python transcription service remains separate and requires hosting. Full instrument-specific transcription is not implemented.
- Android compilation and physical-device tests not performed here. GitHub Actions builds a debug APK. Upload all files including .github/workflows/android.yml.
