from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pathlib import Path
import uuid, shutil
import numpy as np
import librosa
from basic_pitch.inference import predict
from music21 import converter
app=FastAPI()
ROOT=Path('jobs'); ROOT.mkdir(exist_ok=True)
NAMES=['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B']
TEMPLATES=[]
for r in range(12):
    for minor in (False,True):
        v=np.zeros(12); v[[(r+i)%12 for i in (0,3 if minor else 4,7)]]=1
        TEMPLATES.append((NAMES[r]+('m' if minor else ''),v/np.linalg.norm(v)))
@app.post('/analyze')
def analyze(audio:UploadFile=File(...)):
    suffix=Path(audio.filename or '').suffix.lower()
    if suffix not in ('.wav','.mp3','.m4a','.flac'): raise HTTPException(400,'Unsupported format')
    job=uuid.uuid4().hex; folder=ROOT/job; folder.mkdir(); source=folder/('audio'+suffix)
    with source.open('wb') as f: shutil.copyfileobj(audio.file,f)
    y,sr=librosa.load(source,duration=600)
    if len(y)<sr: raise HTTPException(400,'Recording too short')
    bpm,beats=librosa.beat.beat_track(y=y,sr=sr)
    chroma=librosa.feature.chroma_cqt(y=y,sr=sr)
    boundaries=sorted(set([0,*map(int,beats),chroma.shape[1]])); chords=[]
    for a,b in zip(boundaries,boundaries[1:]):
        if b<=a: continue
        v=chroma[:,a:b].mean(axis=1); name=max(TEMPLATES,key=lambda t:float(t[1]@v))[0] if np.linalg.norm(v)>0.05 else 'N.C.'
        if not chords or chords[-1]['chord']!=name: chords.append({'time':round(float(librosa.frames_to_time(a,sr=sr)),2),'chord':name})
    major=np.array([6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88]); minor=np.array([6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17]); avg=chroma.mean(axis=1)
    key=max(((NAMES[r]+mode,float(np.corrcoef(avg,np.roll(profile,r))[0,1])) for r in range(12) for mode,profile in [(' major',major),(' minor',minor)]),key=lambda x:x[1])[0]
    _,midi,_=predict(str(source)); midi.write(str(folder/'score.mid')); converter.parse(str(folder/'score.mid')).write('musicxml',fp=str(folder/'score.musicxml'))
    return {'id':job,'bpm':round(float(np.asarray(bpm).flat[0]),1),'key':key,'chords':chords}
@app.get('/export/{job}/{kind}')
def export(job:str,kind:str):
    if len(job)!=32 or any(c not in '0123456789abcdef' for c in job) or kind not in ('mid','musicxml'): raise HTTPException(404)
    p=ROOT/job/('score.'+kind)
    if not p.is_file(): raise HTTPException(404)
    return FileResponse(p,filename=p.name)
