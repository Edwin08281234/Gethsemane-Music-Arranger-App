import os,secrets,json,sqlite3,time,hmac
from pathlib import Path
from fastapi import FastAPI,Request,HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel,Field
app=FastAPI(title='Gethsemane Music Arranger')
PASSWORD=os.environ.get('GETHSEMANE_PASSWORD',''); USER=os.environ.get('GETHSEMANE_USER','leader')
if len(PASSWORD)<12: raise RuntimeError('Set GETHSEMANE_PASSWORD to at least 12 characters')
tokens={}; sessions={}
def db():
 c=sqlite3.connect('setlists.db'); c.execute('create table if not exists sets (id integer primary key, data text)'); return c
def auth(r):
 t=r.headers.get('authorization','').removeprefix('Bearer ')
 if tokens.get(t,0)<time.time(): raise HTTPException(401)
@app.post('/login')
async def login(r:Request):
 d=await r.json()
 if not(hmac.compare_digest(str(d.get('user','')),USER) and hmac.compare_digest(str(d.get('password','')),PASSWORD)): raise HTTPException(401,'Invalid login')
 t=secrets.token_urlsafe(32);tokens[t]=time.time()+43200;return {'token':t}
@app.get('/sets')
def sets(r:Request):
 auth(r)
 with db() as c:return [{'id':i,**json.loads(d)} for i,d in c.execute('select id,data from sets')]
class Song(BaseModel):
 name:str; key:str='C'; bpm:int=Field(90,ge=30,le=240); meter:int=Field(4,ge=2,le=12); sections:dict[str,str]; lyrics:dict[str,str]=Field(default_factory=dict)
class Setlist(BaseModel):
 name:str; songs:list[Song]
@app.post('/sets')
def save(r:Request,d:Setlist):
 auth(r)
 with db() as c:i=c.execute('insert into sets(data) values(?)',(d.model_dump_json(),)).lastrowid
 return {'id':i}
@app.post('/session')
async def session(r:Request):
 auth(r);d=await r.json();i=d['id']
 with db() as c:row=c.execute('select data from sets where id=?',(i,)).fetchone()
 if not row:raise HTTPException(404)
 t=secrets.token_urlsafe(24);sessions[t]={'set':json.loads(row[0]),'song':0,'section':next(iter(json.loads(row[0])['songs'][0]['sections']),'') if json.loads(row[0])['songs'] else '', 'playing':False,'click':True,'drums':False,'start':time.time()+1,'expires':time.time()+14400};return {'code':t}
@app.get('/live/{code}')
def live(code:str):
 s=sessions.get(code)
 if not s or s['expires']<time.time():raise HTTPException(404)
 return {**s,'now':time.time()}
@app.post('/live/{code}')
async def cue(code:str,r:Request):
 auth(r);s=live(code);d=await r.json();song=int(d.get('song',s['song'])); songs=s['set']['songs']
 if not 0<=song<len(songs):raise HTTPException(400)
 section=d.get('section',s['section']);section=section if section in songs[song]['sections'] else next(iter(songs[song]['sections']),'')
 update={k:bool(d[k]) for k in ['playing','click','drums'] if k in d};update.update(song=song,section=section)
 if song!=s['song'] or (update.get('playing') and not s['playing']):update['start']=time.time()+1
 sessions[code].update(update);return live(code)
@app.get('/')
def home():return HTMLResponse(Path(__file__).with_name('index.html').read_text())
@app.get('/join/{code}')
def join(code:str):live(code);return home()
